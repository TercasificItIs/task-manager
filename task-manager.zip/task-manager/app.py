import streamlit as st
import json
import os

TASKS_FILE = "tasks.json"

def load_tasks():
    if os.path.exists(TASKS_FILE):
        with open(TASKS_FILE, "r") as f:
            return json.load(f)
    return []

def save_tasks(tasks):
    with open(TASKS_FILE, "w") as f:
        json.dump(tasks, f, indent=2)

st.title("My Task Manager")

tasks = load_tasks()

# --- CREATE ---
st.subheader("Add a Task")
new_task = st.text_input("Task title")
if st.button("Add Task"):
    if new_task.strip() != "":
        tasks.append({"title": new_task, "done": False})
        save_tasks(tasks)
        st.rerun()

# --- READ + UPDATE + DELETE ---
st.subheader("Your Tasks")
for i, task in enumerate(tasks):
    col1, col2, col3 = st.columns([6, 1, 1])
    with col1:
        label = f"~~{task['title']}~~" if task["done"] else task["title"]
        st.write(label)
    with col2:
        if st.button("✅", key=f"done_{i}"):
            tasks[i]["done"] = not tasks[i]["done"]
            save_tasks(tasks)
            st.rerun()
    with col3:
        if st.button("🗑️", key=f"delete_{i}"):
            tasks.pop(i)
            save_tasks(tasks)
            st.rerun()